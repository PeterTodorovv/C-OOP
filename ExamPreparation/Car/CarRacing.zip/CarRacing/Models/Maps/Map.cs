﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    internal class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            throw new NotImplementedException();
        }
    }
}
