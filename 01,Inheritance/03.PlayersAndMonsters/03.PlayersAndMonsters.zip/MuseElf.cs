﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.PlayersAndMonsters
{
    class MuseElf : Elf
    {
        public MuseElf(string username, int level) : base(username, level)
        {
        }
    }
}
