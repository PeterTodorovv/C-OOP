﻿using System;

namespace _03.PlayersAndMonsters
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
