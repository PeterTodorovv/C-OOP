﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.PlayersAndMonsters
{
    class DarkKnight : Knight
    {
        public DarkKnight(string username, int level) : base(username, level)
        {
        }
    }
}
