﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Food
{
    internal class Seeds : Food
    {
        public Seeds(int quontity) : base(quontity)
        {
        }
    }
}
