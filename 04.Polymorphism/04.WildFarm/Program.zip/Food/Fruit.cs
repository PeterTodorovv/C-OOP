﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Food
{
    internal class Fruit : Food
    {
        public Fruit(int quontity) : base(quontity)
        {
        }
    }
}
