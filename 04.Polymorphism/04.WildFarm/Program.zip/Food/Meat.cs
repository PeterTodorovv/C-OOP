﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Food
{
    internal class Meat : Food
    {
        public Meat(int quontity) : base(quontity)
        {
        }
    }
}
