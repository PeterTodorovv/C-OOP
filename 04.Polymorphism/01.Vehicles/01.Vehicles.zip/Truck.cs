﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles
{
    internal class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public void Drive(double distance)
        {
            double currentDrive = FuelConsumption * distance + 1.6 * distance;

            if (FuelQuantity >= currentDrive)
            {
                FuelQuantity -= currentDrive;
                Console.WriteLine($"Truck travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Truck needs refueling");
            }
        }

        public void Refuel(double fuel)
        {
            FuelQuantity += fuel * 0.95;
        }
    }
}
