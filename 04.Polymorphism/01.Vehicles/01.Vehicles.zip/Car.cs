﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles
{
    internal class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public void Drive(double distance)
        {
            double currentDrive = FuelConsumption * distance + 0.9 * distance;

            if (FuelQuantity >= currentDrive)
            {
                FuelQuantity -= currentDrive;
                Console.WriteLine($"Car travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Car needs refueling");
            }
        }

        public void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }
    }
}
