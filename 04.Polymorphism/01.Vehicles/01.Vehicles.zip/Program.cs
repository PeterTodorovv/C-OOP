﻿using System;

namespace _01.Vehicles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(' ');
            double cFuel = double.Parse(carInfo[1]);
            double cFuelConsumprion = double.Parse(carInfo[2]);
            Car car = new Car(cFuel, cFuelConsumprion);

            string[] truckInfo = Console.ReadLine().Split(' ');
            double tFuel = double.Parse(truckInfo[1]);
            double tFuelConsumprion = double.Parse(truckInfo[2]);
            Truck truck = new Truck(tFuel, tFuelConsumprion);

            int n = int.Parse(Console.ReadLine());

            for(int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split(' ');
                string command = input[0];
                string vehickeType = input[1];

                if(command == "Drive")
                {
                    double distance = double.Parse(input[2]);
                    if(vehickeType == "Car")
                    {
                        car.Drive(distance);
                    }
                    else if(vehickeType == "Truck")
                    {
                        truck.Drive(distance);
                    }
                }
                else if(command == "Refuel")
                {
                    double fuel = double.Parse(input[2]);
                    if (vehickeType == "Car")
                    {
                        car.Refuel(fuel);
                    }
                    else if (vehickeType == "Truck")
                    {
                        truck.Refuel(fuel);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
