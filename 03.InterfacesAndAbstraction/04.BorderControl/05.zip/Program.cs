﻿using System;
using System.Collections.Generic;

namespace _04.BorderControl
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ');
            List<IId> citizens = new List<IId>();
            List<IBirthDate> birthDates = new List<IBirthDate>();

            while (input[0] != "End")
            {
                if (input[0] == "Robot")
                {
                    string model =  input[0];
                    string id = input[1];
                }
                else if (input[0] == "Citizen")
                {
                    string name = input[1];
                    int age = int.Parse(input[2]);
                    string id = input[3];
                    string birthDate = input[4];
                    birthDates.Add(new Human(name, age, id, birthDate));
                }
                else if(input[0] == "Pet")
                {
                    string name = input[1];
                    string birthDate = input[2];
                    birthDates.Add(new Pet(name, birthDate));
                }

                input = Console.ReadLine().Split(' ');
            }


            string year = Console.ReadLine();

            foreach (var birthdate in birthDates)
            {
                if (birthdate.Birthdate.Substring(birthdate.Birthdate.Length - year.Length) == year)
                {
                    Console.WriteLine(birthdate.Birthdate);
                }
            }
        }
    }
}
