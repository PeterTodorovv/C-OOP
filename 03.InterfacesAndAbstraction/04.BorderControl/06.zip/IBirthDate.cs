﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl
{
    public interface IBirthDate
    {
        public string Birthdate { get; set; }
    }
}
